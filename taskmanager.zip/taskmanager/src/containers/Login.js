import {app} from '../utils/firebase-config';
import {useEffect} from 'react';
export const Login = ()=>{
    useEffect(()=>{
        console.log('FireBase Auth ', app.auth);
        app.auth().onAuthStateChanged(user=>{
            if(user){
                console.log('User Logged In');
            }
            else{
                console.log("User Loggged out");
            }
        })
    },[]);
    const loginWithGmail = ()=>{
        const googleAuthProvider = app.auth.GoogleAuthProvider();
        app.auth().signInWithPopup(googleAuthProvider);
    }
    return (
        <div>
            <a onClick={loginWithGmail} className='btn btn-danger btn-block btn-social btn-google'><span className="fa fa-google"> Login with Gmail</span></a>
            <br/>
            <br/>
            <br/>
            <a className='btn btn-info btn-block btn-social'><span className="fa fa-facebook">Login with FaceBook</span></a>
        </div>
    )
}