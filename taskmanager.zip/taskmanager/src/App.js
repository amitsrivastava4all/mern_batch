import logo from './logo.svg';
import './App.css';
import { Login } from './containers/Login';

function App() {
  return (
    <div className='container'>
      <br/>
        <Login/>
    </div>
  );
}

export default App;
