/*
View the Task (All, Pending, Completed)
*/