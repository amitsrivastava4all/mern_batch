const CONFIG = {
  URL: "https://run.mocky.io/v3/0011b815-cde9-4fb0-b8b2-3700e835a5e1",
};
