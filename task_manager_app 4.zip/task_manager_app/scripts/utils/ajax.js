function doAjax() {
  const promise = fetch(CONFIG.URL);
  return promise;
}
