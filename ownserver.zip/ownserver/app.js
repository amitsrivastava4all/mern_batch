const http = require("http");
const readStaticFile = require("./utils/servefile");
function handleRequestResponse(request, response) {
  //console.log("Request Accepted ");
  console.log(request.url);
  const url = request.url;
  console.log(request.url);
  let contentType = url.endsWith(".css") ? "text/css" : "text/html";
  if (url.startsWith("/login?")) {
    // login check
    response.write("Login");
    response.end();
  } else {
    // serve static file

    response.writeHead(200, { "Content-Type": contentType });
    readStaticFile(url, response);
  }
  //response.write("<h1>Hello Client</h1>");
  // response.end();
}
const server = http.createServer(handleRequestResponse);
const serverObj = server.listen(6789, (err) => {
  if (err) {
    console.log("Error During Server Start");
  } else {
    console.log("Server Started... ", serverObj.address().port);
  }
});
