const fs = require("fs");
const path = require("path");
function readStaticFile(url, response) {
  // HTML, CSS, JS (Client), Fonts, Images
  const parentPath = path.normalize(__dirname + "/..");

  if (url == "/") {
    url = "/index.html";
  }
  const fullPath = path.join(parentPath, "/public", url);
  const stream = fs.createReadStream(fullPath);
  stream.pipe(response);
}
module.exports = readStaticFile;
