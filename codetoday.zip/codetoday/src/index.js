import ReactDOM from "react-dom";
import { App } from "./App";
import React from "react";
//ReactDOM.render(<App />, document.getElementById("root"));
ReactDOM.render(React.createElement(App), document.getElementById("root"));
