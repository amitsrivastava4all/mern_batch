import React from "react";
import "./App.css";
import { Shop } from "./containers/Shop";
export function App() {
  return <Shop />;
  // const myStyle = {
  //   color: "green",
  //   backgroundColor: "yellow",
  // };
  // //return <h1>Hello React JS</h1>;
  // return React.createElement(
  //   "div",
  //   null,
  //   React.createElement("h1", { style: { color: "red" } }, "Hello ReactJS1"),
  //   React.createElement("h1", { style: myStyle }, "Hello ReactJS2"),
  //   React.createElement("h1", { class: "myownstyle" }, "Hello ReactJS3")
  // );
  // return (
  //   <div>
  //     <h1>Hello ReactJS1 </h1>
  //     <h1>Hello ReactJS2 </h1>
  //     <h1>Hello ReactJS3 </h1>
  //   </div>
  // );
}
