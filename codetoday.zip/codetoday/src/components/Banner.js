export function Banner() {
  return <h1>Banner Section</h1>;
}
