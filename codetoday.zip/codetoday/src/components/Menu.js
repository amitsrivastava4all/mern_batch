export function Menu() {
  return <h1>Menu Section</h1>;
}
