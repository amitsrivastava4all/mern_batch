export function Header() {
  return <h1>Header Section</h1>;
}
