/*
    Glue B/w View and Model
    Controller Doing DOM
    Input , Output
*/
window.addEventListener("load", init);
function init() {
  bindEvents();
  countUpdate();
}
function bindEvents() {
  document.querySelector("#add").addEventListener("click", addTask);
}
function countUpdate() {
  document.querySelector("#total").innerText = taskOperations.getTotal();
}
function addTask() {
  // let id = document.querySelector('#id').value;
  // let name = document.querySelector('#name').value;

  const fields = ["id", "name", "descr", "date", "url", "pr"];
  const task = {};
  for (let field of fields) {
    //task.id  = 1001;
    task[field] = document.querySelector(`#${field}`).value;
  }
  let len = taskOperations.add(task);
  printTask(task);
  countUpdate();
  console.log("Task Object is ", task);
}

function printTask(task) {
  let tbody = document.querySelector("#tasks");
  let tr = tbody.insertRow();
  let index = 0;
  for (let key in task) {
    tr.insertCell(index).innerText = task[key];
    index++;
  }
}
