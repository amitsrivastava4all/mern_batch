// CRUD Logic
const taskOperations = {
  tasks: [],
  getTotal() {
    return this.tasks.length;
  },
  add(task) {
    let taskObject = new Task(
      task.id,
      task.name,
      task.descr,
      task.date,
      task.url,
      task.pr
    );
    this.tasks.push(taskObject);
    return this.tasks.length;
  },
  delete() {},
  search() {},
  update() {},
  sort() {},
};
