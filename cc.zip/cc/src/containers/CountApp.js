import React, { Component } from "react";
import { PlusButton } from "../components/PlusButton";
import { Title } from "../components/Title";

export class CountApp extends Component {
  constructor() {
    super();
    this.count = 0;
    this.msg = `Count is ${this.count}`;
    this.state = { msg: this.msg, count: this.count };
    console.log("1. Cons Call ", this);
  }

  plusIt = () => {
    this.count++;
    console.log("N Plus It", this.count);
    this.setState({ count: this.count, msg: `Count is ${this.count}` });
    // setState internally call render
    //this.setState()
  };

  render() {
    console.log("2. Render Call");
    return (
      <div className="container">
        <Title message="Counter App" />
        <PlusButton plusfn={this.plusIt} />
        <Title message={this.state.msg} />
      </div>
    );
  }
}

/*export function CountApp() {
  console.log("Comp Start");
  let count = 0;
  const plusIt = () => {
    count++;
    console.log("Plus It", count);
  };
  let msg = `Count Value is ${count}`;
  return (
    <div className="container">
      <Title message="Counter App" />
      <PlusButton plusfn={plusIt} />
      <Title message={msg} />
    </div>
  );
}*/
