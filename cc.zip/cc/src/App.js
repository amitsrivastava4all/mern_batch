import React from "react";
import { CountApp } from "./containers/CountApp";
function App() {
  return <CountApp />;
}
export default App;
