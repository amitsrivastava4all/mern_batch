// Arrow Fn
export const PlusButton = (props) => {
  return (
    <button onClick={props.plusfn} className="btn btn-success">
      Like
    </button>
  );
};
