// Arrow Fn
import "./Title.css";
export const Title = ({ message }) => {
  const mystyle = {
    color: "yellow",
    backgroundColor: "blue",
  };
  return (
    <h3 className="red" style={mystyle}>
      {message}
    </h3>
  );
};
