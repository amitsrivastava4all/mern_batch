import { Switch, Route } from "react-router-dom";
import { Home } from "../components/Home";
import { TaskAdd } from "../components/TaskAdd";
import { TaskEdit } from "../components/TaskEdit";
import { TaskView } from "../components/TaskView";
export const Section = ({ user, msg }) => {
  return (
    <main className="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <h2>
        {msg} {user?.displayName}
      </h2>
      <img src={user?.photoURL} />

      <hr />
      <Switch>
        <Route path="/" exact component={Home} />
        <Route path="/add" component={TaskAdd} />
        <Route path="/view" component={TaskView} />
        <Route path="/edit/:id/:name" component={TaskEdit} />
        <Route
          path="/delete"
          render={(props) => {
            console.log("Props is ", props);
            return (
              <>
                <h2>I am a Delete Component</h2>
                <button
                  onClick={() => {
                    console.log("####Props is ", props);
                    props.history.push("/view?type=completed&date=25-12-21");
                  }}
                >
                  Move to View
                </button>
              </>
            );
          }}
        />
        <Route
          render={() => {
            return <h2>OOPS Wrong URL</h2>;
          }}
        />
      </Switch>
    </main>
  );
};
