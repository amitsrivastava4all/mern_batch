import firebase, { auth } from "../utils/firebase-config";
import { useEffect, useRef } from "react";
import axios from "axios";
export const Login = ({ islogin }) => {
  const uid = useRef("");
  const pwd = useRef("");
  useEffect(() => {
    console.log("FireBase Auth ", auth);
    auth.onAuthStateChanged((user) => {
      if (user) {
        console.log("User Logged In", user);
        islogin(user, true, "Welcome ");
      } else {
        console.log("User Loggged out");
        islogin(null, false, "User Logged Out");
      }
    });
  }, []);

  const loginWithEmailAndPassword = () => {
    let email = uid.current.value;
    let password = pwd.current.value;
    const promise = axios.post(process.env.REACT_APP_LOGIN_URL, {
      email: email,
      pwd: password,
    });
    promise
      .then((response) => {
        console.log("Response :::: ", response);
        console.log("Data ", response.data);
        console.log(response.data.message, typeof response.data.message);
        if (response.data.message.endsWith("SuccessFully")) {
          alert("Welcome User");
        } else {
          alert("Invalid Userid or password");
        }
      })
      .catch((err) => console.log("Crash ", err));
  };

  const loginWithGmail = () => {
    const authObject = firebase.auth();
    const googleAuthProvider = new firebase.auth.GoogleAuthProvider();
    authObject.signInWithPopup(googleAuthProvider);
    console.log("I am in Google Auth");
  };
  return (
    <div>
      <button
        onClick={loginWithGmail}
        className="btn btn-danger btn-block btn-social btn-google"
      >
        <span className="fa fa-google"> Login with Gmail</span>
      </button>
      <br />
      <br />
      <br />
      <a className="btn btn-info btn-block btn-social">
        <span className="fa fa-facebook">Login with FaceBook</span>
      </a>
      <br />
      <br />
      <p>OR LOGIN With Email and Password</p>

      <br />
      <input ref={uid} type="text" placeholder="Type Email Here" />
      <br />
      <input ref={pwd} type="password" placeholder="Type password Here" />
      <button onClick={loginWithEmailAndPassword}>Login</button>
    </div>
  );
};
