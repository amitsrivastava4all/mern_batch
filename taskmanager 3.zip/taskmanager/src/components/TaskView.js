import { NavLink, Switch } from "react-router-dom";
import { Route } from "react-router-dom";
/*
View the Task (All, Pending, Completed)
*/
export const TaskView = (props) => {
  // console.log("Query String is ", props.location.search);
  // const query = new URLSearchParams(props.location.search);
  // let values = "";
  // for (let param of query.entries()) {
  //   values += param;
  // }
  // console.log("Value is ", values);
  // let arr = values.split(",");
  // console.log(arr);
  // console.log("Values is ", arr[1], arr[2]);
  return (
    <>
      <h1>I am View task</h1>
      {/* <h1>
        I am View task {arr[1]} and {arr[2]}
      </h1> */}
      <NavLink to="/view/pending">Pending</NavLink>
      &nbsp;
      <NavLink to="/view/completed">Completed</NavLink>
      <Switch>
        <Route
          path="/view/pending"
          render={() => {
            return <h1>I am Pending Component </h1>;
          }}
        />
        <Route
          path="/view/completed"
          render={() => {
            return <h1>I am Completed Component </h1>;
          }}
        />
      </Switch>
    </>
  );
};
