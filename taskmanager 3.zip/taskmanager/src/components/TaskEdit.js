export const TaskEdit = (props) => {
  return (
    <h1>
      Task Edit {props.match.params.id} and {props.match.params.name}
    </h1>
  );
};
