// Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";

//import * as firebase from "firebase/app";
import firebase from "firebase/compat/app";
import "firebase/compat/auth"; //v9
import dotenv from "dotenv";
dotenv.config();
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: process.env.REACT_APP_APIKEY,
  authDomain: "taskmanager-app-ead4c.firebaseapp.com",
  projectId: "taskmanager-app-ead4c",
  storageBucket: "taskmanager-app-ead4c.appspot.com",
  messagingSenderId: "78662989789",
  appId: "1:78662989789:web:3ac7d97bf0dbe44f99a834",
  measurementId: "G-ZNX631900M",
};
console.log("FireBase is ", firebase);
// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
console.log("FireBase is ", firebase.auth);
export default firebase;
export const auth = firebase.auth();
