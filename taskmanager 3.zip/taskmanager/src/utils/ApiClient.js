// BackEnd API Calls
import axios from "axios";
export const getMenu = () => {
  return axios.get(process.env.REACT_APP_MENU_URL);
};
