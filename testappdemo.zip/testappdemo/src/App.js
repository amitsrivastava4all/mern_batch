import logo from "./logo.svg";
import "./App.css";
import { Count } from "./components/count";

function App() {
  return <Count />;
}

export default App;
