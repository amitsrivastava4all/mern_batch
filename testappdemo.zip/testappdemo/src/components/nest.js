import propTypes from "prop-types";

export const Nest = (props) => {
  return (
    <p>
      Hello I am Nest {props.name} and {props.age}
    </p>
  );
};
Nest.defaultProps = {
  age: "21",
};
Nest.propTypes = {
  name: propTypes.string.isRequired,
  age: propTypes.string,
};
