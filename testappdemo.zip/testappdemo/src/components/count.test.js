import { Count } from "./count";
import { screen, render } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Nest } from "./nest";
describe("Count Component Test Suite ", () => {
  test("render count check title", () => {
    render(<Count />);
    const txt = screen.getByText("Count is");
    expect(txt).toBeInTheDocument();
  });
  test("render button click changes", () => {
    render(<Count />);
    const button = screen.getByRole("button");
    userEvent.click(button);
    const result = screen.getByText("1");
    expect(result).toBeInTheDocument();
  });
  test("Testng Nested Component", () => {
    render(<Count />);
    render(<Nest />);
    const txt = screen.getByText("Hello I am Nest");
    expect(txt).toBeInTheDocument();
  });
});
