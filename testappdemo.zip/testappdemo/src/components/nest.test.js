import { screen, render } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Nest } from "./nest";
test("Testng Nested Component", () => {
  render(<Nest />);
  const txt = screen.getByText("Hello I am Nest");
  expect(txt).toBeInTheDocument();
});
