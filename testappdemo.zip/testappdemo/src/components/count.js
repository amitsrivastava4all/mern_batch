import React, { useState } from "react";
import { Nest } from "./nest";
export const Count = () => {
  const [c, setCounter] = useState(0);
  const [err, setError] = useState({});
  const plus = () => {
    setCounter(c + 1);
  };
  const validate = (evt) => {
    if (evt.target.value.length < 3) {
      setError({ lenerror: "Less Len" });
    } else {
      setError({ lenerror: "" });
    }
    // useState update error state
  };
  return (
    <>
      <input type="text" onChange={validate} />
      <p>{err.lenerror}</p>
      <button onClick={plus}>OK</button>
      <h1>Count is </h1>
      <p>{c}</p>
      <Nest name="Amit" />
    </>
  );
};
