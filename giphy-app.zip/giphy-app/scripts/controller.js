window.addEventListener("load", () => {
  doAjax("Iron Man");
});
