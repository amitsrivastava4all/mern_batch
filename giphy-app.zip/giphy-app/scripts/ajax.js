function doAjax(name) {
  const apiKey = "vFRSFWo6g7vJ7ZAjt3DMDolU52ORTxwH";
  const URL = `https://api.giphy.com/v1/gifs/search?api_key=${apiKey}&q=${name}&limit=5`;
  let xmlHTTPRequest;
  //https://api.giphy.com/v1/gifs/search
  if (window.XMLHttpRequest) {
    xmlHTTPRequest = new XMLHttpRequest();
  } else {
    // Old IE Browser
    xmlHTTPRequest = new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlHTTPRequest.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      console.log("Rec the Data from the Server ", this.responseText);
    }
    console.log("Ready State ", this.readyState);
    // 0 - request not intialized
    // 1 - server connection establish
    // 2 - request rec
    // 3  - processing XMLHttpRequest
    // 4 - sending response
  };

  xmlHTTPRequest.open("GET", URL, true);
  xmlHTTPRequest.send();
}
