export const Section = () => {
  return (
    <main className="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <h2>Section title</h2>
    </main>
  );
};
