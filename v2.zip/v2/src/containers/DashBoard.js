import { Header } from "../widgets/Header";
import { Section } from "../widgets/Section";
import { SideBar } from "../widgets/SideBar";
import "../assets/css/dashboard.css";

export const DashBoard = () => {
  return (
    <>
      <Header />
      <div className="container-fluid">
        <div className="row">
          <SideBar />
          <Section />
        </div>
      </div>
    </>
  );
};
