window.addEventListener("load", () => {
  getTheAjaxResult("Iron Man");
  bindEvents();
});

const bindEvents = () =>
  document.querySelector("#searchtxt").addEventListener("change", search);

function getTheAjaxResult(searchValue) {
  const promise = doAjax(searchValue);
  promise
    .then((response) => {
      response
        .json()
        .then((object) => {
          console.log("Data is ", object);
          printImages(object);
        })
        .catch((err) => {
          console.log("JSON Parse Error ", err);
        });
    })
    .catch((err) => {
      console.log("Server Error ", err);
    });
}

function search() {
  let searchValue = document.querySelector("#searchtxt").value;
  document.querySelector("#output").innerHTML = "";
  getTheAjaxResult(searchValue);
}

function printImages(obj) {
  let outputDiv = document.querySelector("#output");
  let imagesList = obj.data;
  for (let imageObject of imagesList) {
    let url = imageObject["images"]["original"]["url"];
    let div = document.createElement("div");
    let img = document.createElement("img");
    div.appendChild(img);
    img.src = url;
    outputDiv.appendChild(div);
  }
}

// function printImages(result) {
//   console.log("Result is ", result, " Type of a result is ", typeof result);
//   let obj = JSON.parse(result); // JSON to obj
//   console.log("Object is ", obj);
//   let outputDiv = document.querySelector("#output");
//   let imagesList = obj.data;
//   for (let imageObject of imagesList) {
//     let url = imageObject["images"]["original"]["url"];
//     let div = document.createElement("div");
//     let img = document.createElement("img");
//     div.appendChild(img);
//     img.src = url;
//     outputDiv.appendChild(div);
//   }
// }
