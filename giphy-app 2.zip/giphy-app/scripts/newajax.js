function doAjax(searchValue) {
  const apiKey = "vFRSFWo6g7vJ7ZAjt3DMDolU52ORTxwH";
  const URL = `https://api.giphy.com/v1/gifs/search?api_key=${apiKey}&q=${searchValue}&limit=5`;
  const promise = fetch(URL);
  return promise;
}

function doPostCall() {
  const URL = ""; // Assume some server URL
  // Assume Userid , Password, Name , age
  let userid = document.querySelector("#userid").value;
  let password = document.querySelector("#pwd").value;
  let name = document.querySelector("#name").value;
  let age = document.querySelector("#age").value;
  const userInfo = { userid, password, name, age };

  const options = {
    method: "POST",
    body: JSON.stringify(userInfo),
    headers: {
      "Content-Type": "application/json",
    },
  };
  const promise = fetch(URL, options);
  promise.then((response) => {}).catch((err) => {});
}
