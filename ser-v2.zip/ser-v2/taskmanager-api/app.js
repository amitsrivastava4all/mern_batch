const express = require("express");
//console.log(typeof express);
const { BASE } = require("./utils/config").ROUTES;
const { DEFAULT_PORT } = require("./utils/config");
const app = express();
require("dotenv").config();
app.use(express.static("public")); // Serve Static Files
app.use(express.urlencoded()); // key=value&key=value
app.use(express.json()); // {key:value, key:value}
app.use(require("./utils/middlewares/content"));
app.use(BASE, require("./routes/user"));

// 404 At the End
app.use(require("./utils/middlewares/404"));
//console.log(typeof app);
const server = app.listen(process.env.PORT || DEFAULT_PORT, (err) => {
  if (err) {
    console.log("Error in Server...", err);
  } else {
    console.log("Server Started ", server.address().port);
  }
});
