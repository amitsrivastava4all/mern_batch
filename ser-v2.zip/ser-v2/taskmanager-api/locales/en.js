module.exports = {
  "login.success": "Login SuccessFully",
  "register.success": "Register SuccessFully",
  "login.fail": "Login Fails",
  "resource.notfound": "OOPS U Type Something Wrong in URL",
};
