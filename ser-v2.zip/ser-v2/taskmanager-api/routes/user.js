const express = require("express");
const route = express.Router();
const controller = require("../controllers/user");

const { LOGIN, REGISTER } = require("../utils/config").ROUTES.USER;

route.post(LOGIN, controller.login);
route.post(REGISTER, controller.register);
module.exports = route;
