import { X, obj2, div } from "./one.mjs";
import obj from "./one.mjs";
console.log(obj.add(10, 20));
console.log(obj.sub(10, 20));
console.log(X);
console.log(obj2);
console.log(div());
