//export const obj = {
const obj = {
  add(x, y) {
    return x + y;
  },
  sub(x, y) {
    return x - y;
  },
};
export const X = 100;
export const obj2 = {
  show() {},
};
export const div = () => 1000;
export default obj;
