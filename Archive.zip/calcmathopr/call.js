const calc = require("./index");
console.log(calc.add(10, 20));
console.log(calc.sub());
