module.exports = {
  add(x = 0, y = 0) {
    return x + y;
  },
  sub(x = 0, y = 0) {
    return x - y;
  },
};
