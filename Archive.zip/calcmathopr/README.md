# Calc Package

**Created By Amit Srivastava**
_Support Math Operations_
For More Details Visit [Brain Mentors](https://www.brain-mentors.com)
_Operations are_

- Add Operation
- Sub Operation
