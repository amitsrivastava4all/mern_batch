const chalk = require("chalk");
console.log(chalk.red.bold.underline("Hello Node JS"));
console.log(chalk.bgYellow.green("Hi Node JS"));
