const { sub, mul } = require("./one"); // common js
console.log(sub);
console.log(mul);
