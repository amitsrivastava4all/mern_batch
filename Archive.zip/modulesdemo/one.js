//console.log(arguments);
// (function(exports, require, module, __filename, __dirname){
//     console.log("Hello Node JS ");
// })(); // IIFE
// Public Pattern
// module.exports  = {
//     add(){

//     },
//     delete(){

//     }
// }
const add = () => {};
const sub = () => {};
const mul = () => {};
const public = { sub, mul };
module.exports = public;
