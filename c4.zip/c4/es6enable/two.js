import { show } from "./one.js";
show();
