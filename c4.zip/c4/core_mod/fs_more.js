const fs = require("fs");
const path = "/Users/amitsrivastava/Documents/learn-react";
fs.readdir(path, (err, folders) => {
  console.log("Folders ", folders);
});
// fs.writeFile("test.txt", "Hello Node JS", (err) => {
//   if (err) {
//     console.log(err);
//   } else {
//     console.log("Write done...");
//   }
// });
fs.appendFile("test.txt", "This is the New data to add in a file", (err) => {
  if (err) {
    console.log("Error is ", err);
  } else {
    console.log("Data Appended");
  }
});

fs.copyFile("test.txt", "test2.txt", (err) => {});
let isExist = fs.existsSync("test.txt");
fs.unlink("test.txt", (err) => {});
try {
  fs.mkdirSync("/tmp");
  //gjjgjhgjg
} catch (err) {}
fs.rmdirSync("/tmp");
