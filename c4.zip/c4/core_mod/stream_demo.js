const fs = require("fs");
const bigFile = "/Users/amitsrivastava/Downloads/a.mp4"; // 121 MB
const readStream = fs.createReadStream(bigFile, { highWaterMark: 20000 });
readStream.on("open", () => {
  console.log("Stream Open");
});
readStream.pipe(process.stdout);
// readStream.on("data", function (chunk) {
//   console.log("Chunk Rec ", chunk);
//   this.close();
// });
readStream.on("end", () => {
  console.log("No More Data in Stream ");
});
readStream.on("error", (err) => {
  console.log("Error in Stream ", err);
});
readStream.on("close", () => {
  console.log("Stream close");
});
