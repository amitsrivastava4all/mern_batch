const fs = require("fs");
const zlib = require("zlib");
const bigFile = "/Users/amitsrivastava/Downloads/a.mp4";
const zipFile = "/Users/amitsrivastava/Downloads/a.gz";
fs.createReadStream(bigFile)
  .pipe(zlib.createGzip())
  .pipe(fs.createWriteStream(zipFile));
