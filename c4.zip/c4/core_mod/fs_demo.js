const fs = require("fs");
// Async Version
fs.readFile(__filename, { encoding: "utf-8" }, (err, content) => {
  if (err) {
    console.log("error while reading a file ", err);
  } else {
    console.log("data is ", content.toString());
  }
});

// Sync Version / Blocking Version
try {
  let content = fs.readFileSync(__filename, { encoding: "utf-8" });
  console.log("Sync Content is ", content.toString());
  console.log("###########################################");
} catch (err) {
  console.log("Error while sync file read ", err);
}
