export const Operations = ({ label, cssclass, fn }) => {
  return (
    <button onClick={fn} className={cssclass}>
      {label}
    </button>
  );
};
