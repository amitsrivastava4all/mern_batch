export const Message = ({ label }) => {
  return <h2 className="text-center">{label}</h2>;
};
