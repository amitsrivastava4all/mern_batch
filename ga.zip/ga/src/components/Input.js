export const Input = ({ label, fn, val }) => {
  let placeholder = `Type ${label} Name Here`;
  console.log("INPUT :: ", label, val);
  return (
    <div>
      <label>{label} Name</label>
      {/* <input onChange={fn} type="text" placeholder={placeholder} /> */}
      <input
        value={val}
        onChange={(event) => {
          fn(event, label.toLowerCase());
        }}
        type="text"
        placeholder={placeholder}
      />
    </div>
  );
};
