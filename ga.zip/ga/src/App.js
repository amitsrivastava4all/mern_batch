import { Greet } from "./containers/GreetApp";

const App = () => {
  return <Greet />;
};
export default App;
