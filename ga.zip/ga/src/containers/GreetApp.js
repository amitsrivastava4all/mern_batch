import { Input } from "../components/Input";
import React from "react";
import { Message } from "../components/Message";
import { Operations } from "../components/Operations";
import { initCap } from "../utils/initcap";
export class Greet extends React.Component {
  constructor() {
    super();
    this.names = { first: "", middle: "", last: "" };
    // this.firstName = "";
    // this.lastName = "";

    this.state = { message: "" };
  }

  createInputJSX() {
    let jsx = [];
    for (let key in this.names) {
      console.log("key is ", key);
      jsx.push(
        <Input
          key={key}
          fn={this.takeName.bind(this)}
          label={initCap(key)}
          val={this.names[key]}
        />
      );
    }
    return jsx;
  }

  takeName(event, key) {
    this.names[key] = event.target.value;
    console.log("Take Name Call ", this.names);
    this.setState({ message: "" });
  }
  /*
  takeFirstName(event, x, y) {
    this.firstName = event.target.value;
    console.log(
      "Take First Name ",
      this.firstName,
      "X is ",
      x,
      " and y is ",
      y
    );
  }
  takeLastName(event) {
    this.lastName = event.target.value;
    console.log("Take Last Name ", this.lastName);
  }*/
  printFullName() {
    //let fullName = this.firstName + this.lastName;
    let fullName = "";
    for (let key in this.names) {
      fullName = fullName + initCap(this.names[key]) + " ";
    }
    fullName = fullName.trim();

    this.setState({ message: "Welcome " + fullName });
  }
  clearAll() {
    for (let key in this.names) {
      this.names[key] = "";
    }
    this.setState({ message: "" });
  }
  render() {
    const jsx = this.createInputJSX();
    return (
      <div className="container">
        <Message label="Greet App" />
        {jsx}
        {/* <Input
          fn={this.takeName.bind(this)}
          label="First"
          val={this.names["first"]}
        />
        <Input
          fn={this.takeName.bind(this)}
          label="Middle"
          val={this.names["middle"]}
        />
        <Input
          fn={this.takeName.bind(this)}
          label="Last"
          val={this.names["last"]}
        /> */}
        {/* <Input
          fn={(event) => {
            this.takeFirstName(event, 10, 20);
          }}
          label="First"
        /> */}
        {/* <Input fn={this.takeLastName.bind(this)} label="Last" /> */}
        <Operations
          fn={this.printFullName.bind(this)}
          cssclass="btn btn-primary"
          label="Greet"
        />
        <Operations
          fn={this.clearAll.bind(this)}
          cssclass="btn btn-danger"
          label="Clear All"
        />
        <Message label={this.state.message} />
      </div>
    );
  }
}
