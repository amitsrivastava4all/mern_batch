import logo from "./logo.svg";
import "./App.css";
import { Login } from "./containers/Login";
import { DashBoard } from "./containers/DashBoard";
import { TaskManagerApp } from "./containers/TaskManagerApp";

function App() {
  return <TaskManagerApp />;
}

export default App;
