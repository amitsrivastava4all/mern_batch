export const Home = () => {
  return <h1>I am Home</h1>;
};
