/*
View the Task (All, Pending, Completed)
*/
export const TaskView = () => {
  return <h1>I am View task</h1>;
};
