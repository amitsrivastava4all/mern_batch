import { useState } from "react";
import { Login } from "./Login";
import { DashBoard } from "./DashBoard";
export const TaskManagerApp = () => {
  const [userData, setSuccess] = useState({
    user: {},
    msg: "",
    isSuccess: false,
  });
  const isLogin = (user, successValue, message) => {
    //console.log("Rec User Object ", user);

    setSuccess({ user: user, msg: message, isSuccess: successValue });
  };
  //console.log(":::::::Rec User Object ::: ", userData);
  return (
    <>
      {userData.isSuccess ? (
        <DashBoard userinfo={userData.user} msg={userData.msg} />
      ) : (
        <Login islogin={isLogin} />
      )}
      {/* {<Login />} */}
      {/* <DashBoard /> */}
    </>
  );
};
