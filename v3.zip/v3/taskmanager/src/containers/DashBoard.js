import { Header } from "../widgets/Header";
import { Section } from "../widgets/Section";
import { SideBar } from "../widgets/SideBar";
import "../assets/css/dashboard.css";
import { useEffect, useState } from "react";
import { getMenu } from "../utils/ApiClient";

export const DashBoard = ({ userinfo, msg }) => {
  // Call Web Api to get the Menu Options
  // For Admin different menu options and for guest or normal user different options
  // we call some api for this
  const [menus, setMenus] = useState([]);
  useEffect(() => {
    const promise = getMenu();
    promise
      .then((response) => {
        console.log("Response ", response);
        setMenus(response.data.menus);
      })
      .catch((err) => {
        console.log("Error During Menu Fetch ", err);
      });
    // call menu options
  }, []);
  return (
    <>
      <Header />
      <div className="container-fluid">
        <div className="row">
          <SideBar menus={menus} />
          <Section user={userinfo} msg={msg} />
        </div>
      </div>
    </>
  );
};
