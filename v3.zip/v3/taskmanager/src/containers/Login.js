import firebase, { auth } from "../utils/firebase-config";
import { useEffect } from "react";
export const Login = ({ islogin }) => {
  useEffect(() => {
    console.log("FireBase Auth ", auth);
    auth.onAuthStateChanged((user) => {
      if (user) {
        console.log("User Logged In", user);
        islogin(user, true, "Welcome ");
      } else {
        console.log("User Loggged out");
        islogin(null, false, "User Logged Out");
      }
    });
  }, []);
  const loginWithGmail = () => {
    const authObject = firebase.auth();
    const googleAuthProvider = new firebase.auth.GoogleAuthProvider();
    authObject.signInWithPopup(googleAuthProvider);
    console.log("I am in Google Auth");
  };
  return (
    <div>
      <button
        onClick={loginWithGmail}
        className="btn btn-danger btn-block btn-social btn-google"
      >
        <span className="fa fa-google"> Login with Gmail</span>
      </button>
      <br />
      <br />
      <br />
      <a className="btn btn-info btn-block btn-social">
        <span className="fa fa-facebook">Login with FaceBook</span>
      </a>
    </div>
  );
};
