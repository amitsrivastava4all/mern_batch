const jwt = require("jsonwebtoken");
module.exports = {
  SECRET: process.env.SECRET,
  generateToken(emailid) {
    let tokenId = jwt.sign({ userid: emailid }, this.SECRET, {
      expiresIn: "1h",
    });
    return tokenId;
  },
  verifyToken(tokenId) {
    try {
      let decode = jwt.verify(tokenId, process.env.SECRET);
      return decode && decode.userid;
    } catch (err) {
      console.log("Err is ", err);
      return null;
    }
  },
};
