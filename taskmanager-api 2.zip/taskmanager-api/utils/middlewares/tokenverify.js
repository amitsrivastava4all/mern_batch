const { FILE_NOT_FOUND } = require("../config").STATUS_CODES;
const { verifyToken } = require("../token");
module.exports = (request, response, next) => {
  const tokenId = request.header("authorization");
  console.log("Token Id is ######## ", tokenId);
  if (verifyToken(tokenId)) {
    next();
  } else {
    response
      .status(FILE_NOT_FOUND)
      .json({ message: "Invalid Token , Please do Login First" });
  }
};
