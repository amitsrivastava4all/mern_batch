const winston = require("winston");
const { timestamp, label, printf, combine } = winston.format;
const customFormat = printf(({ level, message, label, timestamp }) => {
  return `[${level}] :::  ${timestamp} => [${label}] :: ${message} `;
});
module.exports = function (moduleName) {
  let logger = winston.createLogger({
    level: "error",
    format: combine(label({ label: moduleName }), timestamp(), customFormat),
    transports: [
      new winston.transports.File({
        filename: "logs/app-error.log",
        level: "error",
        maxsize: 20971520, // 20 MB
        maxFiles: 5,
      }),
      new winston.transports.File({
        filename: "logs/app-debug.log",
        level: "debug",
        maxsize: 20971520, // 20 MB
        maxFiles: 5,
      }),
    ],
  });
  return logger;
};
