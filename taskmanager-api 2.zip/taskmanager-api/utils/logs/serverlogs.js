const fs = require("fs");
const path = require("path");
const root = path.normalize(__dirname + "/../..");
const logFilePath = path.join(root, "/logs/server.log");
const serverLogStream = fs.createWriteStream(logFilePath, { interval: "7d" }); // rotate weekly
module.exports = serverLogStream;
