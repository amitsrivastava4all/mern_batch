module.exports = {
  SCHEMAS: {
    USERS: "users",
    ROLES: "roles",
  },
  CONTENT: {
    TYPE: {
      JSON: "application/json",
    },
  },
  STATUS_CODES: {
    SUCCESS: 200,
    FILE_NOT_FOUND: 404,
    INTERNAL_SERVER_ERROR: 500,
  },
  DEFAULT_PORT: 5555,
  ROUTES: {
    BASE: "/",
    USER: {
      LOGIN: "/login",
      REGISTER: "/register",
    },
  },
};
