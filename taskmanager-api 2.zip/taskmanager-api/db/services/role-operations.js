// CRUD Operations
const RoleModel = require("../models/role-schema");

const roleOperations = {
  addRole(roleObject) {
    // add operation

    return RoleModel.create(roleObject);
  },
  async getRoleInfo(name) {
    try {
      const document = await RoleModel.findOne({
        name: name,
      });
      console.log("Doc is ", document);
      return document;
    } catch (err) {
      console.log("Unable to find the role by name ", err);
    }
    return null;
  },
};
module.exports = roleOperations;
//roleOperations.addRole({ name: "Admin", description: "Admin Role" });
