// CRUD Operations
const UserModel = require("../models/user-schema");
const roleOperations = require("./role-operations");
const encrypt = require("../../utils/encrypt");
const userOperations = {
  async register(userObject, role = "Admin") {
    // add operation
    userObject.password = encrypt.passwordHash(userObject.password);
    const roleInfo = await roleOperations.getRoleInfo(role);
    console.log("Role Info in Reg ", roleInfo);
    userObject.role = roleInfo._id;
    return UserModel.create(userObject);
  },
  async login(userObject) {
    try {
      //UserModel.find({name:'Amit'},'name age address')
      //UserModel.deleteMany({name:'Amit'})
      //UserModel.deleteOne({name:'Amit'})
      //UserModel.updateOne({name:'Amit'},{pwd:'a111'});
      // UserModel.updateMany({name:'Amit'}, {pwd:'amit11'});
      //UserModel.findByIdAndUpdate(id:ObjectId)
      //UserModel.findByIdAndDelete(id:'');
      //UserModel.find({role:'Admin'}) ;// Search All Admin (Start to End Search)
      //UserModel.findById(id:_id) ; Primary Key (ObjectId) wise find
      const document = await UserModel.findOne({
        email: userObject.email, // Exit from the first occurance
        //,
        //password: userObject.pwd,
      }).populate("role");
      console.log("Doc is ", document);
      if (document && document.email) {
        let encryptedPwd = document.password;
        if (encrypt.compareHash(userObject.pwd, encryptedPwd)) {
          return document;
        }
      }
      return null;
    } catch (err) {
      console.log(":::::::Unable to do the login operation ", err);
    }
    return null;
  },
};
module.exports = userOperations;
