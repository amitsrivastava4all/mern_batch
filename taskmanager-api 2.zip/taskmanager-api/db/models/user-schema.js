const connection = require("../connection");
const { Schema, SchemaTypes } = require("mongoose");
const { USERS, ROLES } = require("../../utils/config").SCHEMAS;
const userSchema = new Schema({
  email: { type: SchemaTypes.String, required: true, unique: true },
  password: { type: SchemaTypes.String, required: true, min: 8, max: 25 },
  role: {
    // Join
    type: SchemaTypes.ObjectId,
    ref: ROLES, // Schema Name (Join Create)
    required: true,
  },
  logintime: { type: SchemaTypes.Date, default: new Date() },
});
const UserModel = connection.model(USERS, userSchema);
module.exports = UserModel;
