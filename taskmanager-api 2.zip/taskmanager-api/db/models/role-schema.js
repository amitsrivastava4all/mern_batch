const connection = require("../connection");
const { Schema, SchemaTypes } = require("mongoose");
const { USERS, ROLES } = require("../../utils/config").SCHEMAS;
const RoleSchema = new Schema({
  name: { type: SchemaTypes.String, required: true, unique: true },
  description: { type: SchemaTypes.String, required: true },
  status: { type: SchemaTypes.String, default: "A" },
  /*user: {
    // Join
    type: SchemaTypes.ObjectId,
    ref: USERS, // Schema Name (Join Create)
    required: true,
  },*/
});
const RoleModel = connection.model(ROLES, RoleSchema);
module.exports = RoleModel;
