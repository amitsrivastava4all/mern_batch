const mongoose = require("mongoose");
mongoose.connect(
  process.env.DB_URL
    ? process.env.DB_URL
    : "mongodb+srv://amit:amit123@cluster0.h4yun.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
  {
    maxPoolSize: 5,
  },
  (err) => {
    if (err) {
      console.log("DB Connection Error ", err);
    } else {
      console.log("DB Connection Created...");
    }
  }
);
module.exports = mongoose;
