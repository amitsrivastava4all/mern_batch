const express = require("express");
//console.log(typeof express);
const { BASE } = require("./utils/config").ROUTES;
const { DEFAULT_PORT } = require("./utils/config");
const app = express();
require("dotenv").config();
const serverLogStream = require("./utils/logs/serverlogs");
const morgan = require("morgan");
const logger = require("./utils/logs/applogs")(__filename);
const cors = require("cors");
app.use(cors());
const fileUpload = require("express-fileupload");
app.use(morgan("combined", { stream: serverLogStream }));
app.use(express.static("public")); // Serve Static Files
app.use(express.urlencoded()); // key=value&key=value
app.use(express.json()); // {key:value, key:value}
app.use(require("./utils/middlewares/content"));
app.set("view engine", "ejs");
//app.set('views',pathofejsfolder);
app.use(fileUpload());
app.use(BASE, require("./routes/user"));
//app.use(require("./utils/middlewares/tokenverify"));
app.use(BASE, require("./routes/task"));
app.use(BASE, require("./routes/serve"));
app.use(BASE, require("./routes/upload_download"));
// 404 At the End
app.use(require("./utils/middlewares/404"));
//console.log(typeof app);
const server = app.listen(process.env.PORT || DEFAULT_PORT, (err) => {
  if (err) {
    logger.error("Error in Server Start " + err);
    //console.log("Error in Server...", err);
  } else {
    logger.debug("Server Started " + server.address().port);
    console.log("Server Started ", server.address().port);
  }
});
