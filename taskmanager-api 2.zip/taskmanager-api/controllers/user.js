const { SUCCESS, INTERNAL_SERVER_ERROR } =
  require("../utils/config").STATUS_CODES;
const messageBundle = require("../locales/en");
const tokenOperations = require("../utils/token");
const userOperations = require("../db/services/user-operations");
const sendMail = require("../utils/mail");
const login = async (request, response) => {
  console.log("Data Rec ", request.body);
  const body = request.body;
  const userObject = { email: body.email, pwd: body.pwd };
  const document = await userOperations.login(userObject);
  if (document && document.email) {
    let token = tokenOperations.generateToken(document.email);
    response.status(SUCCESS).json({
      message: messageBundle["login.success"],
      user: document.email,
      role: document.role,
      token,
    });
  } else {
    response.status(200).json({ message: messageBundle["login.fail"] });
  }
  //response.send("Login ");
};

const register = (request, response) => {
  const body = request.body;
  const userObject = { email: body.email, password: body.pwd };
  const promise = userOperations.register(userObject);
  promise
    .then((res) => {
      // sendMail();
      response
        .status(SUCCESS)
        .json({ message: messageBundle["register.success"] });
    })
    .catch((err) => {
      console.log("Fail During Register ", err);
      response
        .status(INTERNAL_SERVER_ERROR)
        .json({ message: messageBundle["register.fail"] });
    });
};
module.exports = { login, register };
