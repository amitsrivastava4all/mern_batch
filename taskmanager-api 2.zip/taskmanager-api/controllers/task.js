const { SUCCESS, INTERNAL_SERVER_ERROR } =
  require("../utils/config").STATUS_CODES;
const messageBundle = require("../locales/en");
const tokenOperations = require("../utils/token");
const userOperations = require("../db/services/user-operations");
const add = (request, response) => {
  response.send("Task Add");
};

const view = (request, response) => {
  response.send("Task View");
};

module.exports = { add, view };
