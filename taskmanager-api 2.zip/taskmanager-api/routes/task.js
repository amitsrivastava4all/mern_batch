const express = require("express");
const route = express.Router();
const controller = require("../controllers/task");

route.get("/add", controller.add);
route.get("/view", controller.view);
module.exports = route;
