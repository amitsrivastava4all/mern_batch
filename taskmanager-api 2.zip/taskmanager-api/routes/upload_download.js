const express = require("express");
const route = express.Router();
const path = require("path");

route.get("/download", (request, response) => {
  const fileName = "26551351.png";
  const fullPath = path.join(
    path.normalize(__dirname + "/.."),
    "/uploads",
    fileName
  );
  console.log(fullPath);
  response.setHeader("Content-disposition", "attachment; filename=" + fileName);
  response.setHeader("Content-type", "image/png");
  response.download(fullPath, (err) => {
    console.log(err);
  });
  //response.send("Download It");
});
route.post("/upload", (request, response) => {
  console.log("Request ::: ", request.files);
  if (!request.files || Object.keys(request.files).length == 0) {
    response.send("No File to Upload..");
  } else {
    let file = request.files.uploadfile;

    let fullPath = path.join(
      path.normalize(__dirname + "/.."),
      "/uploads",
      file.name
    );
    file.mv(fullPath, (err) => {
      if (err) {
        response.send("File Upload Error");
      } else {
        response.send("Upload Done...");
      }
    });
  }
});
module.exports = route;
