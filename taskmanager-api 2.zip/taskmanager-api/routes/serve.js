const express = require("express");
const route = express.Router();
route.get("/server-page", (request, response) => {
  let qs = request.query;
  console.log(qs);
  response.set({ "Content-Type": "text/html" });
  let obj = { ...qs, city: "Delhi" };
  response.render("dynamic", obj);
});
module.exports = route;
