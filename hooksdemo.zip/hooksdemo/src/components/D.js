import { DataContext } from "../utils/DataContext";

export const D = () => {
  return (
    <DataContext.Consumer>
      {(value) => {
        return (
          <h1>
            I am D Component {value.counter} Name {value.name}
          </h1>
        );
      }}
    </DataContext.Consumer>
  );
};
