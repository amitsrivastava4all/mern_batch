import { C } from "./C";

export const B = () => {
  return (
    <>
      <h1>I am B Component</h1>
      <C />
    </>
  );
};
