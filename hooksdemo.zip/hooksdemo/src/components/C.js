import { D } from "./D";

export const C = () => {
  return (
    <>
      <h1>I am C Component</h1>
      <D />
    </>
  );
};
