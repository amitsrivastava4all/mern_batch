import { useRef, useState } from "react";

export const Input = () => {
  // Top Level
  //const [arr, setUser] = useState([{}, 0, [], {}]);
  //   const [users, setUser] = useState({"user":{ name: "", phone: "", email: "" }, "admin":{}});
  const [user, setUser] = useState({ name: "", phone: "", email: "" });
  const name = useRef();
  const phone = useRef();
  const email = useRef();
  const register = () => {
    let myName = name.current.value;
    let myPhone = phone.current.value;
    let myEmail = email.current.value;
    setUser({ name: myName, phone: myPhone, email: myEmail });
  };
  return (
    <>
      <h1>
        Name is {user.name} Phone is {user.phone} Email is {user.email}
      </h1>
      <input type="text" ref={name} placeholder="Type Name Here" />
      <br />
      <input type="text" ref={phone} placeholder="Type Phone Here" />
      <br />
      <input type="text" ref={email} placeholder="Type Email Here" />
      <br />
      <button onClick={register}>Register</button>
    </>
  );
};
