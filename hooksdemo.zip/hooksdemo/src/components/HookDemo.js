import React, { useState } from "react";
import { Input } from "./Input";
import { LifeCycle } from "./LifeCycle";
export const HookDemo = () => {
  const [counter, setCounter] = useState(0);
  const plusIt = () => {
    setCounter(counter + 1);
    console.log("Plus It");
  };
  return (
    <>
      {counter > 10 ? <Input /> : <LifeCycle />}
      <h1>Hook Example</h1>
      <h2>Counter is {counter}</h2>
      <button onClick={plusIt}>Plus</button>
    </>
  );
};
