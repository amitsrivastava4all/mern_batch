import { DataContext } from "../utils/DataContext";
import { B } from "./B";

export const A = () => {
  return (
    <>
      <h1>I am A Component</h1>
      <DataContext.Provider value={{ counter: 2, name: "Amit" }}>
        <B />
      </DataContext.Provider>
    </>
  );
};
