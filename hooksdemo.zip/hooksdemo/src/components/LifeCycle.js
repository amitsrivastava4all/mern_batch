import React, { useEffect, useState } from "react";

export const LifeCycle = React.memo(() => {
  const [c, setCounter] = useState(0);
  // Updation Phase
  useEffect(() => {
    console.log("Component Did Mount + Component Did Update");
  });
  // Mounting Phase
  useEffect(() => {
    console.log("Component Did Mount");
  }, []);
  const plus = () => {
    setCounter(c + 1);
  };
  // UnMounting Phase
  useEffect(() => {
    return () => {
      console.log("Component Will UnMount....");
    };
  }, []);
  return (
    <>
      <h1> Life Cycle Hooks {c}</h1>
      <button onClick={plus}>Plus</button>
    </>
  );
});
