import React from "react";
export const DataContext = React.createContext({ counter: 0, name: "" });
