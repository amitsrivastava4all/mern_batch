import logo from "./logo.svg";
import "./App.css";
import { HookDemo } from "./components/HookDemo";
import { Input } from "./components/Input";
import { LifeCycle } from "./components/LifeCycle";
import { A } from "./components/A";

function App() {
  return <A />;
}

export default App;
