// const obj = require("./calc");
const { add, sub } = require("./calc");
// console.log(obj);
// console.log(obj.add(10, 20));
// console.log(obj.sub(100, 99));
console.log(add(10, 20));
console.log(sub(10, 1));
// const result = fn(10, 20);
// console.log(result);
