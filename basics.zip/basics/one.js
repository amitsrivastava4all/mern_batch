const fs = require("fs"); // file system
var a = 100;
var b = 200;
var c = a + b;
//"c:\\abcd\\sample.txt"
const path =
  "/Users/amitsrivastava" +
  "/Documents/learn-node-codes" +
  "/basics/sample.txt";
fs.readFile(path, (err, buffer) => {
  if (err) {
    console.log("Error is ", err);
  } else {
    console.log("Content is ", buffer.toString());
  }
}); // Async
console.log("C is ", c);
