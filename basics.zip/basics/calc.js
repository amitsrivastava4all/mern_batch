// module.exports = function (first, second) {
//   return first + second;
// };
// module.exports.add = function add(first, second) {
//   return first + second;
// };
// module.exports.sub = function subtract(first, second) {
//   return first - second;
// };
// module.exports.mul = function mul(first, second) {
//   return first * second;
// };

// function add(first, second) {
//   return first + second;
// }
// function subtract(first, second) {
//   return first - second;
// }
// function mul(first, second) {
//   return first * second;
// }
// module.exports = { add, sub: subtract, mul };
// const calc = {
//   add(first, second) {
//     return first + second;
//   },
//   sub: function (first, second) {
//     return first - second;
//   },
//   mul(first, second) {
//     return first * second;
//   },
// };
// function add(first, second) {
//   return first + second;
// }
// function subtract(first, second) {
//   return first - second;
// }
// function mul(first, second) {
//   return first * second;
// }

//const calc = { add, sub: subtract, mul };
//module.exports = calc;
console.log(exports === module.exports);
console.log(module.exports, exports);
// module.exports = {
//   add(first, second) {
//     return first + second;
//   },
//   sub: function (first, second) {
//     return first - second;
//   },
//   mul(first, second) {
//     return first * second;
//   },
// };
exports = {
  add(first, second) {
    return first + second;
  },
  sub: function (first, second) {
    return first - second;
  },
  mul(first, second) {
    return first * second;
  },
};
module.exports = exports;
