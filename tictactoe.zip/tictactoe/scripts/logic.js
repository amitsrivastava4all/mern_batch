window.addEventListener("load", bindEvents);
let buttons;
function bindEvents() {
  buttons = document.getElementsByTagName("button");

  for (let button of buttons) {
    button.addEventListener("click", printXor0);
  }
}
const isNotBlank = (currentButton) => currentButton.innerText.length == 1;
const isSame = (one, two, three) =>
  one.innerText === two.innerText && one.innerText === three.innerText;

const isSameRow = (one, two, three) =>
  isNotBlank(one) &&
  isNotBlank(two) &&
  isNotBlank(three) &&
  isSame(one, two, three);
let isOver = false;
function isGameOver() {
  if (isSameRow(buttons[0], buttons[1], buttons[2])) {
    isOver = true;
  } else if (isSameRow(buttons[3], buttons[4], buttons[5])) {
    isOver = true;
  } else if (isSameRow(buttons[6], buttons[7], buttons[8])) {
    isOver = true;
  } else if (isSameRow(buttons[0], buttons[3], buttons[6])) {
    isOver = true;
  } else if (isSameRow(buttons[1], buttons[4], buttons[7])) {
    isOver = true;
  } else if (isSameRow(buttons[2], buttons[5], buttons[8])) {
    isOver = true;
  } else if (isSameRow(buttons[0], buttons[4], buttons[8])) {
    isOver = true;
  } else if (isSameRow(buttons[2], buttons[4], buttons[6])) {
    isOver = true;
  }
  return isOver;
}

function reset() {
  count = 0;
  flag = true;
  document.getElementById("result").innerText = "";
  for (let button of buttons) {
    button.innerText = "";
    isOver = false;
  }
}

let count = 0;
var flag = true;
function printXor0() {
  console.log("PrintXor0 Fn Called...", this);

  if (this.innerText.length == 0 && !isOver) {
    count++;
    // var label = flag === true ? "X" : "0";
    // this.innerText = label;
    this.innerText = flag === true ? "X" : "0";
    flag = !flag;
  }
  if (count === 9) {
    document.getElementById("result").innerText = "Game Draw";
    setTimeout(reset, 6000);
  }
  if (count >= 5) {
    let isOver = isGameOver();
    if (isOver) {
      flag = !flag;
      let label = flag === true ? "X" : "0";
      document.getElementById(
        "result"
      ).innerText = `Game Over ${label} is Winner`;
      setTimeout(reset, 6000);
      //reset();
    }
  }
}
