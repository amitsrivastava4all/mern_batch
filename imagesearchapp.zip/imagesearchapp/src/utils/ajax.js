// from here we r calling GIPHY API
import axios from "axios";
// Global Settings
axios.defaults.baseURL = "https://api.giphy.com";
axios.defaults.timeout = 7000;
axios.defaults.headers.get["Content-Type"] = "application/json";

// Custom Instance and Setting for Custom Instance
const axiosInstance = axios.create({ baseURL: "https://api.giphy.com" });
axiosInstance.defaults.timeout = 8000;

export function getTheImages(searchItem) {
  //const BASE_URL = "https://api.giphy.com";
  const API_KEY = "vFRSFWo6g7vJ7ZAjt3DMDolU52ORTxwH";
  const LIMIT = 5;
  let URL =
    // BASE_URL +
    "/v1/gifs/search" + `?api_key=${API_KEY}&q=${searchItem}&limit=${LIMIT}`;
  //axios.all([axios.get(), axios.post()])
  //const promise = axios.post('/login',{userid:'amit',password:'1111'});
  //const promise = axios.get(URL); // axios methods (axios.get, axios.post)
  // const promise = axios({
  //   // method:'POST',
  //   method: "GET",
  //   url: URL,
  //   timeout: 7000,
  //   maxContentLength: 10000,
  //   //data:{userid:'amit',password:'1111'} // For Post Call
  // }); // Generic Version
  // const promise = axiosInstance({
  const promise = axios({
    method: "GET",
    url: URL,
    timeout: 7000,
    maxContentLength: 10000,
  });
  //const promise = axiosInstance.get(URL);
  return promise;
}
