import axios from "axios";
export const loadAuthInterceptor = () => {
  console.log("Auth Interceptor Runs");
  axios.interceptors.request.use(
    (request) => {
      request.tokenid = "A12345"; // localStorage.tokenid
      console.log("Token Attach ", request.tokenid);
      return request;
    },
    (err) => {
      return Promise.reject(err);
    }
  );
};
