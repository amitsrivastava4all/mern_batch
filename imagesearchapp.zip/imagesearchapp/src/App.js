import axios from "axios";
import { SearchApp } from "./containers/SearchApp";
import { interceptor } from "./utils/interceptors/LoggingInterceptor";

const App = () => {
  return <SearchApp />;
};
export default App;
