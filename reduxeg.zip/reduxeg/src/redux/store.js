import {createStore} from 'redux';
import { CalcReducer } from './reducers/calc_reducer';
export const store = createStore(CalcReducer);
store.subscribe(()=>{
    console.log(':::::::: State has been updated .... ', store.getState());
})
