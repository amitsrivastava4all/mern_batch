export const action = (typename, payloaddata)=>{
    return {
        type:typename,
        payload:payloaddata
    }
}
    
