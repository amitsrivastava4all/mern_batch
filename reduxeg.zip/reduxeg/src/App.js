import logo from './logo.svg';
import './App.css';
import { Calc } from './container/Calc';

function App() {
  return (
    <Calc/>
  );
}

export default App;
