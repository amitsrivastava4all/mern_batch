import { Input } from "../components/Input"
import { Operations } from "../components/Operations"
import  Output  from "../components/Output"

 export const Calc = (props)=>{
    return (
        <div className='container'>
               <h1 className='alert-info text-center'>Calc App</h1> 
               <Input lbl='First Number'/>
               <Input lbl='Second Number'/>
               <br/>
               <Operations lbl='+'/>
               <Operations lbl='-'/>
               <Operations lbl='*'/>
               <Operations lbl='/'/>
               <br/>
               <br/>
               <Output/>
        </div>
    )
}
