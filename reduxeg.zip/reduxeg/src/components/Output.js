import {connect} from 'react-redux';
const Output = (props)=>{
    return (<h3>Result is {props.output}</h3>)
}

const mapStateToProps = state=>{
    const props = {
        'output':state.result
    }
    return props;
}
export default connect(mapStateToProps)(Output);