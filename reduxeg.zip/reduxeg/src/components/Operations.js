import {store} from '../redux/store';
import {action} from '../redux/actions/action';
export const Operations = ({lbl})=>{
    return (<>
    <button className='btn btn-primary' onClick={()=>{
            if(lbl=='+'){
                store.dispatch(action('ADD',{}));
            }
    }}>{lbl}</button> &nbsp;&nbsp;
    </>);
}