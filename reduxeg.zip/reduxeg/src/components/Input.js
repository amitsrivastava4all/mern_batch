import {store} from '../redux/store';
import {action} from '../redux/actions/action'

export const Input = ({lbl})=>{
    
    
    
    const takeValue = (event)=>{
        let val = event.target.value;
        console.log('Value is ',val);
        let actionObject = {};
        if(lbl.startsWith("First")){
            actionObject =  action('STORE',{firstNumber:val,...actionObject});
           
       
        }
        else{
            actionObject = action('STORE',{secondNumber:val, ...actionObject});
            
        }
        console.log('Action Object ',actionObject);
        store.dispatch(actionObject);
    }
    let msg = `Enter the ${lbl}`;
    return (<div className='form-group'>
        <label>{lbl}</label>
        <input onChange={takeValue} className='form-control' type='text' placeholder={msg}/>

    </div>)
}