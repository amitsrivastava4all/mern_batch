const express  = require('express');
//console.log(typeof express);
const app = express();
app.use(express.static('public')); // Serve Static Files
//console.log(typeof app);
const server = app.listen(1234, err=>{
    if(err){
        console.log('Error in Server...', err);
    }
    else{
        console.log('Server Started ', server.address().port);
    }
})