import React from "react";
import { Comp2 } from "./Comp2";
import { SearchApp } from "./SearchApp";
export class LifeCycleComponent extends React.Component {
  constructor() {
    super(); // parent component constructor call
    console.log("1. Cons Call");
    this.c = 0;
    this.state = { count: 0 };
  }
  // Dep
  UNSAFE_componentWillMount() {
    console.log("2. Before Component Mount (Render)");
  }
  static getDerivedStateFromProps(nextProps, prevState) {
    // Rarely Used
    console.log("getDerivedStateFromProps Called");
    return null; // null state or initial state
  }

  plusIt() {
    this.c++;
    this.setState({ count: this.c }); // SetState in Immutable Way
  }
  UNSAFE_componentWillReceiveProps() {
    console.log("Updation phase UNSAFE_componentWillReceiveProps ");
  }
  UNSAFE_componentWillUpdate() {
    console.log("Updation phase UNSAFE_componentWillUpdate ");
  }
  shouldComponentUpdate(nextProps, nextState) {
    console.log("UPdation Phase shouldComponentUpdate");
    // if (this.state == nextState && this.props == nextProps) {
    //   return false;
    // } else {
    //   return true;
    // }
    // if (this.state.x == nextState.x) {
    //   return false;
    // } else {
    //   return true;
    // }
    // if (nextState.count < 10) {
    //   return false;
    // } else {
    //   console.log("UPdation Phase shouldComponentUpdate");
    //   return true;
    // }
    return true;
  }
  componentDidUpdate() {
    console.log("Updation Phase componentDidUpdate (After Render)");
  }
  render() {
    console.log("3. Render Call");
    return (
      <div>
        <h1>Count is {this.state.count}</h1>
        {this.state.count >= 12 ? <SearchApp /> : <Comp2 />}
        <button
          onClick={() => {
            this.plusIt();
          }}
        >
          Plus
        </button>
      </div>
    );
  }
}
