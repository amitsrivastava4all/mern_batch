import React from "react";

export class Comp2 extends React.PureComponent {
  render() {
    return <h2>Comp2 </h2>;
  }
  componentWillUnmount() {
    console.log("Bye Bye Comp2");
  }
}
