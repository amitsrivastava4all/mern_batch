import React from "react";
import { Images } from "../components/Images";
import { SearchBox } from "../components/SearchBox";
import { getTheImages } from "../utils/ajax";
import load from "../assets/ajax-loader.gif";
export class SearchApp extends React.Component {
  constructor() {
    super();
    this.txtValue = "";
    this.state = { result: [] };
    console.log("1. Constructor Call");
  }
  UNSAFE_componentWillMount() {
    console.log("2. componentWillMount");
  }

  getTheTextBoxValue(event) {
    this.txtValue = event.target.value;
  }

  getTheImagesFromTheServer() {
    const promise = getTheImages(this.txtValue);
    promise
      .then((response) => {
        console.log("Response ", response.data.data);
        this.setState({ result: response.data.data });
      })
      .catch((err) => {
        console.log("Error is ", err);
      });
  }
  render() {
    console.log("3. Rendering");
    return (
      <div className="container">
        <h1 className="alert-info text-center">Image Search App</h1>
        <SearchBox
          takeTxtBoxValue={this.getTheTextBoxValue.bind(this)}
          searchIt={this.getTheImagesFromTheServer.bind(this)}
        />

        {this.state.result.length == 0 ? (
          <img src={load} />
        ) : (
          <Images list={this.state.result} />
        )}
      </div>
    );
  }
  componentDidMount() {
    console.log("4. componentDidMount");
    const promise = getTheImages("Tom and Jerry");
    promise
      .then((response) => {
        console.log("Response ", response.data.data);
        this.setState({ result: response.data.data });
      })
      .catch((err) => {
        console.log("Error is ", err);
      });
  }
}
