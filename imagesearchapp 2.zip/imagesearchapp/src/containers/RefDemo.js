import React, { Component } from "react";
export class RefDemo extends Component {
  constructor() {
    super();
    console.log(this);
    // this.email = React.createRef();
    // this.name = React.createRef();
    // this.phone = React.createRef();

    this.setEmail = (element) => {
      this.email = element;
    };
    this.setName = (element) => {
      console.log("Element ", element);
      // element.focus();
      this.email.focus();
    };
    this.setPhone = (element) => {
      this.phone = element;
    };
  }
  register() {
    // let email = this.refs.t1.value;
    // let name = this.refs.t2.value;
    // let phone = this.refs.t3.value;
    let email = this.email.current.value;
    // let name = this.name.current.value;
    // let phone = this.phone.current.value;
    //console.log(email, name, phone);
    console.log("Email is ", email);
  }
  render() {
    return (
      <div>
        <input type="text" ref={this.setEmail} placeholder="Type email id " />
        <br />
        <input type="text" placeholder="Type Name " />
        <br />
        {/* <input type="text" ref={this.name} placeholder="Type Name " />
        <br />
        <input type="text" ref={this.phone} placeholder="Type Phone " /> */}
        <button
          onClick={this.setName}
          //   onClick={() => {
          //     // this.register();
          //     this.setName();
          //   }}
        >
          Register
        </button>
      </div>
    );
  }
}
