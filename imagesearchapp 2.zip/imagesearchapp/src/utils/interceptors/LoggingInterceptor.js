import axios from "axios";
let startTime;
let reqInterceptor;
let resInterceptor;

export const loadLoggingInterceptor = () => {
  console.log("Load Logging Interceptor Runs");
  reqInterceptor = axios.interceptors.request.use((request) => {
    startTime = Date.now();
    console.log("Start Time ", startTime);
    return request;
  });
  resInterceptor = axios.interceptors.response.use((response) => {
    let endTime = Date.now();
    let takenTime = endTime - startTime;
    console.log("End Time ", endTime);
    console.log("Total Time Taken ", takenTime);
    return response;
  });
};
setTimeout(() => {
  axios.interceptors.request.eject(reqInterceptor);
  axios.interceptors.response.eject(resInterceptor);
  console.log("Logging Interceptor Off ");
}, 10000);
