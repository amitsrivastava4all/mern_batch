import axios from "axios";
import { LifeCycleComponent } from "./containers/LifeCycleComponent";
import { RefDemo } from "./containers/RefDemo";
import { SearchApp } from "./containers/SearchApp";
import { interceptor } from "./utils/interceptors/LoggingInterceptor";

const App = () => {
  // return <LifeCycleComponent />;
  return <RefDemo />;
};
export default App;
