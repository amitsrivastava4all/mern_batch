export const Image = ({ url, index }) => {
  let altTxt = `Image${index + 1} not found`;
  return <img alt={altTxt} src={url} width="200" height="200" />;
};
