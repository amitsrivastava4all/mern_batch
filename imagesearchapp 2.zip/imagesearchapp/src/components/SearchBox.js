export const SearchBox = ({ takeTxtBoxValue, searchIt }) => {
  return (
    <div className="form-group">
      <label>Search Image</label>
      <input
        onChange={takeTxtBoxValue}
        className="form-control"
        type="text"
        placeholder="Type to Search Image"
      />
      <br />
      <button onClick={searchIt} className="btn btn-primary">
        SearchIt
      </button>
    </div>
  );
};
