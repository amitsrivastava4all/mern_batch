import { Image } from "./Image";

export const Images = ({ list }) => {
  return (
    <div>
      <p>Images Comes Here {list.length}</p>
      {list.map((singleImage, index) => (
        <Image
          key={index}
          index={index}
          url={singleImage.images.original.url}
        />
      ))}
    </div>
  );
};
