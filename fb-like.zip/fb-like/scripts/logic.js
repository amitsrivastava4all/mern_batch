var countValue = 0;
window.addEventListener("load", bindEvents);
function bindEvents() {
  document.getElementById("likeimg").addEventListener("click", count);
}
//document.getElementById("likeimg").addEventListener("click", count);
function count() {
  countValue++;
  document.getElementById("like").innerText = countValue;
}
