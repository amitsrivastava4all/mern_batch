import { useState } from "react";
import { Input } from "../components/Input";
import { Operations } from "../components/Operations";
import { Output } from "../components/Output";

export const Calc = (props) => {
  const [lbl, setLabel] = useState("");
  const whichOneClicked = (label) => {
    setLabel(label);
  };
  return (
    <div className="container">
      <h1 className="alert-info text-center">Calc App</h1>
      <Input lbl="First Number" />
      <Input lbl="Second Number" />
      <br />
      <Operations lbl="+" whichOneClicked={whichOneClicked} />
      <Operations lbl="-" whichOneClicked={whichOneClicked} />
      <Operations lbl="*" />
      <Operations lbl="/" />
      <Operations lbl="sin" whichOneClicked={whichOneClicked} />
      <br />
      <br />
      <Output lbl={lbl} />
    </div>
  );
};
