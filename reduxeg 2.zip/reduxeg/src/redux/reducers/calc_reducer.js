export const CalcReducer = (
  state = { firstNumber: 0, secondNumber: 0, result: 0 },
  action
) => {
  console.log("Reducer ", action);
  if (action.type === "STORE") {
    if (action.payload.firstNumber) {
      return { ...state, firstNumber: action.payload.firstNumber };
    } else {
      return { ...state, secondNumber: action.payload.secondNumber };
    }
  }
  if (action.type === "ADD") {
    let result = parseInt(state.firstNumber) + parseInt(state.secondNumber);
    return { ...state, result };
  } else if (action.type === "SUBTRACT") {
    let result = parseInt(state.firstNumber) - parseInt(state.secondNumber);
    return { ...state, result };
  }
  return state;
};
