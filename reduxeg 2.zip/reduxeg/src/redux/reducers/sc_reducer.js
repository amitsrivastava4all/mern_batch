export const scReducer = (
  state = { firstNumber: 0, secondNumber: 0, result: 0 },
  action
) => {
  console.log("scReducer :::: ", action.type, "State ", state);
  if (action.type === "STORE") {
    if (action.payload.firstNumber) {
      return { ...state, firstNumber: action.payload.firstNumber };
    } else {
      return { ...state, secondNumber: action.payload.secondNumber };
    }
  }
  if (action.type === "SIN") {
    state = {
      ...state,
      result: Math.sin(state.firstNumber) + Math.sin(state.secondNumber),
    };
  }
  console.log("sc Reducer Exit ", state);
  return state;
};
