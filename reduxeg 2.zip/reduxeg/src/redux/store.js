import { combineReducers, createStore } from "redux";
import { CalcReducer } from "./reducers/calc_reducer";
import { scReducer } from "./reducers/sc_reducer";
export const store = createStore(combineReducers({ CalcReducer, scReducer }));
store.subscribe(() => {
  console.log(":::::::: State has been updated .... ", store.getState());
});
