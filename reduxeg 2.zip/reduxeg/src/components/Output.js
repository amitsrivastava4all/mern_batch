import { connect, useSelector } from "react-redux";

export const Output = ({ lbl }) => {
  const data = useSelector((state) =>
    lbl == "sin" ? state.scReducer.result : state.CalcReducer.result
  );
  //return (<h3>Result is {props.output}</h3>)
  return <h3>Result is {data}</h3>;
};

// const mapStateToProps = state=>{
//     const props = {
//         'output':state.result
//     }
//     return props;
// }
// export default connect(mapStateToProps)(Output);
