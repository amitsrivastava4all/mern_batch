import { store } from "../redux/store";
import { action } from "../redux/actions/action";
export const Operations = ({ lbl, whichOneClicked }) => {
  return (
    <>
      <button
        className="btn btn-primary"
        onClick={() => {
          if (lbl === "+") {
            store.dispatch(action("ADD", {}));
          } else if (lbl === "-") {
            store.dispatch(action("SUBTRACT", {}));
          } else if (lbl === "sin") {
            store.dispatch(action("SIN", {}));
          }
          whichOneClicked(lbl);
        }}
      >
        {lbl}
      </button>{" "}
      &nbsp;&nbsp;
    </>
  );
};
