// CRUD Logic
const taskOperations = {
  tasks: [],
  getTotal() {
    return this.tasks.length;
  },
  getAllTasks() {
    return this.tasks;
  },
  add(task) {
    let taskObject = new Task(
      task.id,
      task.name,
      task.descr,
      task.date,
      task.url,
      task.pr
    );
    this.tasks.push(taskObject);
    return this.tasks.length;
  },
  remove() {
    this.tasks = this.tasks.filter((task) => !task.markForDelete);
    return this.tasks;
  },
  countMark() {
    return this.tasks.filter((task) => task.markForDelete).length;
  },
  mark(id) {
    let taskObject = this.searchById(id);
    if (taskObject) {
      taskObject.toggle();
    }
  },

  searchById(id) {
    return this.tasks.find((task) => task.id == id);
  },
  update() {},
  sort() {},
};
