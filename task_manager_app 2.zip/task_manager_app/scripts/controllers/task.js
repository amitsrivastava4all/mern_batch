/*
    Glue B/w View and Model
    Controller Doing DOM
    Input , Output
*/
window.addEventListener("load", init);
function init() {
  bindEvents();
  countUpdate();
}
function bindEvents() {
  document.querySelector("#add").addEventListener("click", addTask);
  document.querySelector("#delete").addEventListener("click", deleteTasks);
}
function deleteTasks() {
  taskOperations.remove();
  printTasks();
  countUpdate();
}
function countUpdate() {
  let mark = taskOperations.countMark();
  let total = taskOperations.getTotal();
  document.querySelector("#unmarktotal").innerText = total - mark;
  document.querySelector("#marktotal").innerText = mark;

  document.querySelector("#total").innerText = total;
}
function addTask() {
  // let id = document.querySelector('#id').value;
  // let name = document.querySelector('#name').value;

  const fields = ["id", "name", "descr", "date", "url", "pr"];
  const task = {};
  for (let field of fields) {
    //task.id  = 1001;
    task[field] = document.querySelector(`#${field}`).value;
  }
  let len = taskOperations.add(task);
  printTask(task);
  countUpdate();
  console.log("Task Object is ", task);
}

function edit() {
  console.log("I am edit");
}
function markForDelete() {
  /*
  For Marking in an object
  1. Get the id from the current icon (u set it eariler)
  2. then search the id in an array and get the object and toggle it
  */
  let id = this.getAttribute("task-id");
  console.log("I am delete ", id);
  taskOperations.mark(id);
  /*
  To make it red
  */
  let tr = this.parentNode.parentNode;
  //tr.className = "alert-danger";
  tr.classList.toggle("alert-danger");
  countUpdate();
  // let currentIcon = this;
  // let td = currentIcon.parentNode;
  // let tr  = td.parentNode;
}

function createIcon(className, fn, taskid) {
  let icon = document.createElement("i");
  // <i class="fas fa-edit"></i>
  // <i class="fas fa-trash-alt"></i>
  icon.className = `fas ${className} click`;
  icon.addEventListener("click", fn); // Attach Event
  icon.setAttribute("task-id", taskid);
  return icon;
}

function printTasks() {
  document.querySelector("#tasks").innerHTML = "";
  let tasks = taskOperations.getAllTasks();
  tasks.forEach(printTask);
}

function printTask(task) {
  let tbody = document.querySelector("#tasks");
  let tr = tbody.insertRow();
  let index = 0;
  for (let key in task) {
    if (key == "markForDelete") {
      continue;
    }
    tr.insertCell(index).innerText = task[key];
    index++;
  }
  let editIcon = createIcon("fa-edit me-2", edit, task.id);
  let deleteIcon = createIcon("fa-trash-alt", markForDelete, task.id);
  let td = tr.insertCell(index);
  td.appendChild(editIcon);
  td.appendChild(deleteIcon);
}
