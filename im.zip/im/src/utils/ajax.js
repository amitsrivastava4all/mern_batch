// from here we r calling GIPHY API
import axios from "axios";
export function getTheImages(searchItem) {
  const BASE_URL = "https://api.giphy.com";
  const API_KEY = "vFRSFWo6g7vJ7ZAjt3DMDolU52ORTxwH";
  const LIMIT = 5;
  let URL =
    BASE_URL +
    "/v1/gifs/search" +
    `?api_key=${API_KEY}&q=${searchItem}&limit=${LIMIT}`;
  const promise = axios.get(URL);
  return promise;
}
