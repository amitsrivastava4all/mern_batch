import { SearchApp } from "./containers/SearchApp";

const App = () => {
  return <SearchApp />;
};
export default App;
