import React from "react";
import { Images } from "../components/Images";
import { SearchBox } from "../components/SearchBox";
import { getTheImages } from "../utils/ajax";
export class SearchApp extends React.Component {
  constructor() {
    super();
    this.txtValue = "";
    this.state = { result: [] };
  }

  getTheTextBoxValue(event) {
    this.txtValue = event.target.value;
  }

  getTheImagesFromTheServer() {
    const promise = getTheImages(this.txtValue);
    promise
      .then((response) => {
        console.log("Response ", response.data.data);
        this.setState({ result: response.data.data });
      })
      .catch((err) => {
        console.log("Error is ", err);
      });
  }
  render() {
    return (
      <div className="container">
        <h1 className="alert-info text-center">Image Search App</h1>
        <SearchBox
          takeTxtBoxValue={this.getTheTextBoxValue.bind(this)}
          searchIt={this.getTheImagesFromTheServer.bind(this)}
        />
        <Images list={this.state.result} />
      </div>
    );
  }
}
