const path = require("path");
const fullPath = path.join(__dirname, "a/b/c.txt");
console.log(fullPath);
const parentDir = path.normalize(__dirname + "/../..");
console.log(parentDir);
///Users/amitsrivastava/Documents/learn-node-codes/core_mod/a/b/c.txt
console.log("Dir Path ", path.dirname(fullPath));
console.log("File Name ", path.basename(fullPath, ".txt"));
console.log("Ext ", path.extname(fullPath));
console.log("Del ", path.delimiter); //: ;
console.log("Sep ", path.sep); // / \
const obj = path.parse(fullPath); // fullpath (String) to object
console.log(obj);
const path2 = path.format(obj); // object to path (String)
console.log(path2);
