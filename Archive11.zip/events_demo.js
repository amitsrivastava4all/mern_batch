const events = require("events");
const eventEmitterObject = new events.EventEmitter();

function openDoor() {
  console.log("Open the Door");
}

function openGate() {
  console.log("Open the Gate");
}

function pickUpTheCall(userName) {
  console.log("Hello " + userName);
}
eventEmitterObject.on("pingpong", openGate);
//eventEmitterObject.addListener("pingpong", openDoor); // Register an event and when the event fire this function will be called
eventEmitterObject.once("pingpong", openDoor);
eventEmitterObject.emit("pingpong"); // fire or call the event
eventEmitterObject.emit("pingpong");
eventEmitterObject.emit("pingpong");
eventEmitterObject.on("ringring", pickUpTheCall);
eventEmitterObject.emit("ringring", "Amit"); // pickUpTheCall("Amit")
//eventEmitterObject.off("pingpong");
eventEmitterObject.removeAllListeners("pingpong");
